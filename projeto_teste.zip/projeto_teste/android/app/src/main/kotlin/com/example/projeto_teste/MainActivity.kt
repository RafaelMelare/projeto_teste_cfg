package com.example.projeto_teste

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
